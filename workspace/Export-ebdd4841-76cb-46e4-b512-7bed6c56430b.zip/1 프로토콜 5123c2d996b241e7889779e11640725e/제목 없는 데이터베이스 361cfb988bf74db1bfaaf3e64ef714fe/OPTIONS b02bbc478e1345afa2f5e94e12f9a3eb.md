# OPTIONS

설명: 메소드 종류를 불러옴