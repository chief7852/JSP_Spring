package kr.or.ddit.enums;

public enum Results {
	OK, FAIL, NOTEXIST, INVALIDPASSWORD, PKDUPLICATED
}
