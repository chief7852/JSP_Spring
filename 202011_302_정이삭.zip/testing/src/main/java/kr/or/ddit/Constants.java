package kr.or.ddit;

public class Constants {
	public static final String SESSIONCOUNTATTRNAME = "sessionCount";
	public static final String USERLISTATTRNAME = "userList";
}
